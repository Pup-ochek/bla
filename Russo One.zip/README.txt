Russo means Russian. It seems strange that in a such font there is no snow, vodka or bears. What I wanted to show is that Russian culture is quite varied and modern. In Russia, too, some people love good fonts and typography. Russo One is designed for headlines and logotypes. It is simple and original, stylish and casual.

Russo One is a Unicode typeface family that supports languages that use the Cyrillic, Baltic, Turkish, Central Europe, Latin script and its variants, and could be expanded to support other scripts.

To contribute to the project contact [Jovanny Lemonad](mailto:lemonad@jovanny.ru).